
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RamosFamily
 */
public class tictactoe extends javax.swing.JFrame {
    
    //Variables
    private String  whoseTurn = "X";
    private String playerone = "Player one";
    private String playertwo = "Player two";
    private int playeronecount = 0;
    private int playertwocount = 0;
    private String playersTurn = "";
    private int tiecount = 0;
    private String tie = "Tie Game";
    
    private String ten = "Click to Start Game";
     
    
       /**
     * Creates new method form tictactoe
     */
    public tictactoe() {
        initComponents();           
        setSize(800,800);
        setLocationRelativeTo(null);
        //getPlayerNames();
        setScore();
        setPlayerName();  
        
         //startgame();
               
    }
    
      
     private void tieGame()
    {
        //Variables
        String one = jButton1.getText();
        String two = jButton2.getText();
        String three = jButton3.getText();
        String four = jButton4.getText();
        String five = jButton5.getText();
        String six = jButton6.getText();
        String seven = jButton7.getText();
        String eight = jButton8.getText();
        String nine = jButton9.getText();
             
        
       if(one != "" && two != "" && three != "" && four != "" &&
               five != "" && six != "" && seven != "" && eight != "" && 
              nine != "")
        
       {
          JOptionPane.showMessageDialog(this, "Game is a tie!", "Tie Game", 
                  JOptionPane.INFORMATION_MESSAGE);
          tiecount++;
           resetGame();
        }    
        
    }
     //Create a metod to set score of players
    private void setScore()
    {       
        jLabel_Score.setText(playerone + " Score is: " + String.valueOf(playeronecount));
        
        jLabel_Score3.setText( playertwo + " Score is : " + String.valueOf(playertwocount));
        
        jLabel_Score4.setText(tie + " : " +  String.valueOf(tiecount) );
               
    }
    //Set the turns of players
    private void setPlayerName()
                   
    {         
        String playersTurn;
        if(whoseTurn.equalsIgnoreCase("X"))
        {
            playersTurn = playerone;
        }else
        {
            playersTurn = playertwo;
        }        
        jLabel_Score2.setText( playersTurn + "'s turn" );
      
        
    }
  //Use method to determine who win the game    
    private void determineWhoseTurn()
    {
        if (whoseTurn.equalsIgnoreCase("X"))
        {
            whoseTurn = "O";
            
        }
        else{
            whoseTurn = "X";
        }
        
    }
    
    
    //Method when X win
    private void xWins()
    {
        JOptionPane.showMessageDialog(this,
              playerone +  " wins",
                "Winner",
                JOptionPane.INFORMATION_MESSAGE);
        playeronecount++;
        resetGame();
        
        
    }
    //Method when O win
    private void oWins()
    {
         JOptionPane.showMessageDialog(this,
              playertwo +  " wins",
                "Winner",
                JOptionPane.INFORMATION_MESSAGE);
          playertwocount++;
         resetGame();
          
    }
    //Clear all buttons
    private void resetGame()
    {
        jButton1.setText("");
        jButton2.setText("");
        jButton3.setText("");
        jButton4.setText("");
        jButton5.setText("");
        jButton6.setText("");
        jButton7.setText("");
        jButton8.setText("");
        jButton9.setText("");
        setScore();
        resetGame();
    }
                   
    
    //Method to deterine winner
    
    private void determineWin(){
    
        String one = jButton1.getText();
        String two = jButton2.getText();
        String three = jButton3.getText();
        String four = jButton4.getText();
        String five = jButton5.getText();
        String six = jButton6.getText();
        String seven = jButton7.getText();
        String eight = jButton8.getText();
        String nine = jButton9.getText();
        
        
        if(one == "X" && two == "X" && three == "X")
        {
            xWins();
        }
        if(four == "X" && five == "X" && six == "X")
        {
            xWins();
        }
        if(seven == "X" && eight == "X" && nine == "X")
        {
            xWins();
        }
        if(one == "X" && four == "X" && seven == "X")
        {
            xWins();
        }
        if(two== "X" && five == "X" && eight== "X")
        {
            xWins();
        }
        if(three == "X" && six == "X" && nine == "X")
        {
            xWins();
        }
        if(seven == "X" && five == "X" && three == "X")
        {
            xWins();
        }
        if(one == "X" && five == "X" && nine == "X")
        {
            xWins();
        }
        
        //If 0 wins
        
         if(one == "O" && two == "O" && three == "O")
        {
            oWins();
        }
        if(four == "O" && five == "O" && six == "O")
        {
            oWins();
        }
        if(seven == "O" && eight == "O" && nine == "O")
        {
            oWins();
        }
        if(one == "O" && four == "O" && seven == "O")
        {
            oWins();
        }
        if(two== "O" && five == "O" && eight== "O")
        {
           oWins();
        }
        if(three == "O" && six == "O" && nine == "O")
        {
            oWins();
        }
        if(seven == "O" && five == "O" && three == "O")
        {
            oWins();
        }
        if(one == "O" && five == "O" && nine == "O")
        {
            oWins();
        }           
        
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel_Board = new javax.swing.JPanel();
        jPanel_1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jPanel_2 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jPanel_3 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jPanel_4 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jPanel_5 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        jPanel_6 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jPanel_7 = new javax.swing.JPanel();
        jButton7 = new javax.swing.JButton();
        jPanel_8 = new javax.swing.JPanel();
        jButton8 = new javax.swing.JButton();
        jPanel_9 = new javax.swing.JPanel();
        jButton9 = new javax.swing.JButton();
        jLabel_Score = new javax.swing.JLabel();
        jLabel_Score2 = new javax.swing.JLabel();
        jLabel_Score3 = new javax.swing.JLabel();
        jLabel_Score4 = new javax.swing.JLabel();
        jButton_Start = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TIC TAC TOE");
        setBackground(new java.awt.Color(51, 255, 51));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setForeground(new java.awt.Color(51, 0, 51));

        jPanel_Board.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 0), 3));
        jPanel_Board.setPreferredSize(new java.awt.Dimension(400, 400));
        jPanel_Board.setLayout(new java.awt.GridLayout(3, 3, 1, 1));

        jPanel_1.setLayout(new java.awt.BorderLayout());

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel_1.add(jButton1, java.awt.BorderLayout.CENTER);

        jPanel_Board.add(jPanel_1);

        jPanel_2.setLayout(new java.awt.BorderLayout());

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel_2.add(jButton2, java.awt.BorderLayout.CENTER);

        jPanel_Board.add(jPanel_2);

        jPanel_3.setLayout(new java.awt.BorderLayout());

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel_3.add(jButton3, java.awt.BorderLayout.CENTER);

        jPanel_Board.add(jPanel_3);

        jPanel_4.setLayout(new java.awt.BorderLayout());

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel_4.add(jButton4, java.awt.BorderLayout.CENTER);

        jPanel_Board.add(jPanel_4);

        jPanel_5.setLayout(new java.awt.BorderLayout());

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel_5.add(jButton5, java.awt.BorderLayout.CENTER);

        jPanel_Board.add(jPanel_5);

        jPanel_6.setLayout(new java.awt.BorderLayout());

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel_6.add(jButton6, java.awt.BorderLayout.CENTER);

        jPanel_Board.add(jPanel_6);

        jPanel_7.setLayout(new java.awt.BorderLayout());

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel_7.add(jButton7, java.awt.BorderLayout.CENTER);

        jPanel_Board.add(jPanel_7);

        jPanel_8.setLayout(new java.awt.BorderLayout());

        jButton8.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel_8.add(jButton8, java.awt.BorderLayout.CENTER);

        jPanel_Board.add(jPanel_8);

        jPanel_9.setLayout(new java.awt.BorderLayout());

        jButton9.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel_9.add(jButton9, java.awt.BorderLayout.CENTER);

        jPanel_Board.add(jPanel_9);

        jLabel_Score.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel_Score.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel_Score.setText("Set Scores");

        jLabel_Score2.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel_Score2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Score2.setText("Player Turn");

        jLabel_Score3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel_Score3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel_Score3.setText("Set Scores");

        jLabel_Score4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel_Score4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Score4.setText("Set Scores");

        jButton_Start.setText("Click to set player's names");
        jButton_Start.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_StartActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(273, 273, 273)
                        .addComponent(jLabel_Score2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(195, 195, 195)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel_Board, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel_Score, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(130, 130, 130)
                                .addComponent(jLabel_Score3, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(319, 319, 319)
                        .addComponent(jLabel_Score4, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(338, 338, 338)
                        .addComponent(jButton_Start)))
                .addContainerGap(147, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel_Score2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jPanel_Board, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addComponent(jButton_Start, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_Score, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel_Score3, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel_Score4, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(86, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        jButton1.setText(whoseTurn);
        if (whoseTurn.equalsIgnoreCase("X")){
            jButton1.setForeground(Color.BLUE);
        }else{
            jButton1.setForeground(Color.ORANGE);
        }           
        determineWhoseTurn();
        determineWin();
        setPlayerName();
        tieGame();
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         jButton2.setText(whoseTurn);
        if (whoseTurn.equalsIgnoreCase("X")){
            jButton2.setForeground(Color.BLUE);
        }else{
            jButton2.setForeground(Color.ORANGE);
        }
        determineWhoseTurn();
        determineWin();
        setPlayerName();
        tieGame();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         jButton3.setText(whoseTurn);
        if (whoseTurn.equalsIgnoreCase("X")){
            jButton3.setForeground(Color.BLUE);
        }else{
            jButton3.setForeground(Color.ORANGE);
        }
        determineWhoseTurn();
        determineWin();
        setPlayerName();
        tieGame();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
         jButton4.setText(whoseTurn);
        if (whoseTurn.equalsIgnoreCase("X")){
            jButton4.setForeground(Color.BLUE);
        }else{
            jButton4.setForeground(Color.ORANGE);
        }
        determineWhoseTurn();
        determineWin();
        setPlayerName();
        tieGame();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
         jButton5.setText(whoseTurn);
        if (whoseTurn.equalsIgnoreCase("X")){
            jButton5.setForeground(Color.BLUE);
        }else{
            jButton5.setForeground(Color.ORANGE);
        }
        determineWhoseTurn();
        determineWin();
        setPlayerName();
        tieGame();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
         jButton6.setText(whoseTurn);
        if (whoseTurn.equalsIgnoreCase("X")){
            jButton6.setForeground(Color.BLUE);
        }else{
            jButton6.setForeground(Color.ORANGE);
        }
        determineWhoseTurn();
        determineWin();
        setPlayerName();
        tieGame();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
         jButton7.setText(whoseTurn);
        if (whoseTurn.equalsIgnoreCase("X")){
            jButton7.setForeground(Color.BLUE);
        }else{
            jButton7.setForeground(Color.ORANGE);
        }
        determineWhoseTurn();
        determineWin();
        setPlayerName();
        tieGame();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
         jButton8.setText(whoseTurn);
        if (whoseTurn.equalsIgnoreCase("X")){
            jButton8.setForeground(Color.BLUE);
        }else{
            jButton8.setForeground(Color.ORANGE);
        }
        determineWhoseTurn();
        determineWin();
        setPlayerName();
        tieGame();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
         jButton9.setText(whoseTurn);
        if (whoseTurn.equalsIgnoreCase("X")){
            jButton9.setForeground(Color.BLUE);
        }else{
            jButton9.setForeground(Color.ORANGE);
        }
        determineWhoseTurn();
        determineWin();
        setPlayerName();
        tieGame();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton_StartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_StartActionPerformed
        jButton_Start.setText(ten);
        //startgame();
        //getPlayerNames();
        playerone = JOptionPane.showInputDialog(this, "player one name",
        "Player  Name", JOptionPane.INFORMATION_MESSAGE);
        
        playertwo = JOptionPane.showInputDialog(this, "player two name",
        "Player Name", JOptionPane.INFORMATION_MESSAGE);
        if(playerone.equals(""))
         {
            playerone = "Player one";
         }
        if(playertwo.equals(""))
        {
            playertwo = "Player two";
        }
             setPlayerName();
              setScore();
              resetGame();
             
    }//GEN-LAST:event_jButton_StartActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tictactoe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tictactoe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tictactoe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tictactoe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tictactoe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JButton jButton_Start;
    private javax.swing.JLabel jLabel_Score;
    private javax.swing.JLabel jLabel_Score2;
    private javax.swing.JLabel jLabel_Score3;
    private javax.swing.JLabel jLabel_Score4;
    private javax.swing.JPanel jPanel_1;
    private javax.swing.JPanel jPanel_2;
    private javax.swing.JPanel jPanel_3;
    private javax.swing.JPanel jPanel_4;
    private javax.swing.JPanel jPanel_5;
    private javax.swing.JPanel jPanel_6;
    private javax.swing.JPanel jPanel_7;
    private javax.swing.JPanel jPanel_8;
    private javax.swing.JPanel jPanel_9;
    private javax.swing.JPanel jPanel_Board;
    // End of variables declaration//GEN-END:variables

   
}
